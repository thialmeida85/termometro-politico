from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from resemblyzer import VoiceEncoder, preprocess_wav

APP_VERSION = "0.1.0"
THRESHOLD = float(os.getenv("VOICE_THRESHOLD", "0.70"))
MARGIN = float(os.getenv("VOICE_MARGIN", "0.08"))


def load_profiles() -> dict[str, np.ndarray]:
    raw = os.getenv("VOICEPRINTS_JSON", "").strip()
    profile_file = os.getenv("VOICEPRINTS_FILE", "").strip()
    if raw:
        payload = json.loads(raw)
    elif profile_file and Path(profile_file).exists():
        payload = json.loads(Path(profile_file).read_text())
    else:
        raise RuntimeError("VOICEPRINTS_JSON or VOICEPRINTS_FILE is required")
    return {
        name: np.asarray(data["embedding"], dtype=np.float32)
        for name, data in payload.items()
        if "embedding" in data
    }


app = FastAPI(title="TruthMeter Voice API", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in os.getenv("ALLOWED_ORIGINS", "*").split(",")],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"]
)

try:
    PROFILES = load_profiles()
    ENCODER = VoiceEncoder("cpu")
    STARTUP_ERROR = None
except Exception as exc:  # API remains healthy enough to report configuration errors.
    PROFILES = {}
    ENCODER = None
    STARTUP_ERROR = str(exc)


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    denominator = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.dot(a, b) / denominator) if denominator else -1.0


@app.get("/health")
def health() -> dict:
    return {
        "ok": STARTUP_ERROR is None,
        "service": "truthmeter-voice-api",
        "version": APP_VERSION,
        "profiles": sorted(PROFILES.keys()),
        "error": STARTUP_ERROR,
    }


@app.post("/v1/identify")
async def identify(audio: UploadFile = File(...)) -> dict:
    if STARTUP_ERROR or ENCODER is None or not PROFILES:
        raise HTTPException(status_code=503, detail="Voice profiles are not configured")
    if not audio.content_type or not (audio.content_type.startswith("audio/") or audio.filename):
        raise HTTPException(status_code=415, detail="Send an audio file")

    data = await audio.read()
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Audio file is too large")

    suffix = Path(audio.filename or "sample.wav").suffix or ".wav"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=True) as temp:
        temp.write(data)
        temp.flush()
        try:
            waveform = preprocess_wav(temp.name)
            embedding = ENCODER.embed_utterance(waveform)
        except Exception as exc:
            raise HTTPException(status_code=422, detail=f"Could not process audio: {exc}") from exc

    scores = {name: cosine(embedding, profile) for name, profile in PROFILES.items()}
    ordered = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    winner, winner_score = ordered[0]
    second_score = ordered[1][1] if len(ordered) > 1 else -1.0
    margin = winner_score - second_score
    accepted = winner_score >= THRESHOLD and margin >= MARGIN

    return {
        "classification": winner if accepted else "unknown",
        "scores": {name: round(score, 4) for name, score in scores.items()},
        "winner_score": round(winner_score, 4),
        "margin": round(margin, 4),
        "threshold": THRESHOLD,
        "required_margin": MARGIN,
        "indeterminate": not accepted,
        "disclaimer": "Similarity is not proof of civil identity; validate with independent samples.",
    }
